#include<iostream>
using namespace std;

class Point
{
int x,y;
public:
void setpoint(int,int);
void showpoint();
};


class point
{
int X,Y;
public:

point()
{
X=0;
Y=0;
}

void setPoint(int a,int b)
{
X=a;
Y=b;
}

void showPoint()
{
cout <<"(a,b) = "<<"("<<X<<","<<Y<<")";

}
};

int main()
{
point p1,P1;
p1.setPoint(5,10);
p1.showPoint();

return 0;
}