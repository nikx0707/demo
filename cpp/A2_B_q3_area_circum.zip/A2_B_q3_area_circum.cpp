#include<iostream>
#define PI 3.14

using namespace std;

void area(int r)
{
    float area;
    area = PI * (r * r);
    cout<<"Area of the Circle is : "<<area<<endl;
}

void circumference( int r)
{
    float circumference;
    circumference = 2 * PI * r;
    cout<<"Circumfernece of the Circle is : "<<circumference<<endl;
}

int main()
{
    int radius;

    cout<<"Enter the Radius of Circle : ";
    cin>>radius;

    area(radius);
    circumference(radius);

    return 0;
}