#include<iostream>
using namespace std;

class Height
{   int n;
    float num[10], sum=0.0, avg;

    public:
        void accept();
        void average();
};

void Height :: accept(){
 

    for (int i = 0; i < n; i++)
    {
        cout<<i+1<<". Enter the Number: ";
        cin>>num[i];
        sum+=num[i];
    }
}

void Height :: average(){
    avg = sum / n ;
    cout<<"The Average = "<<avg;   
}

int main(){
    int n;
    cout<<"Enter the Numbers : ";
    cin>>n;

    Height h1;
    h1.accept();
    h1.average();
}