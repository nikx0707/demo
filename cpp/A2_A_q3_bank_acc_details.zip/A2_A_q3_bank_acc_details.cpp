#include <iostream>
#include <string.h>
#include<iomanip>
using namespace std;

void deposit(int amount, int balnc)
{

    int rm_amt;
    rm_amt = balnc + amount;
    cout << " Your Modified Balance in Bank Account is : " << rm_amt << " $" << endl;
}

int main()
{
    int amt ;
    float balance;
    double acc_no, contact_number;
    string acc_holder_name;
    string addr;

    cout << "Enter Your Bank Account Details : " << endl;
    cout << " 1. Enter Accoumt Number : ";
    cin >> acc_no;

    cout << " 2. Enter Account Holder Name : ";
    cin >> acc_holder_name;

    cout << " 3. Enter Address : ";
    cin >> addr;
    
    cout << " 4. Enter Contact Number : ";
    cin >> contact_number;

    cout << " 5. Enter Balance : ";
    cin >> balance;

    cout << endl
         << "Your Entered Details Are : " << endl
         << "                   Account Number = " << setprecision(11)<<acc_no << endl
         << "                   Account Holder Name = " << acc_holder_name << endl
         << "                   Address = " << addr << endl
         << "                   Contact Number = " << setprecision(10)<< contact_number << endl
         << "                   Balance = " << balance << " $" << endl;

    cout << endl
         << "Enter the Amount to be Deposit : ";
    cin >> amt;

    deposit(amt, balance);

   return 0; 
}