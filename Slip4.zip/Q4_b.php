<?php

$xml_data=simplexml_load_file("Q4_b.xml"); 

foreach ($xml_data->children() as $data)
{ 
  $run=$data->runs;
  $wic=$data->wickets;
  $name=$data->player; if($run >=1200 && $wic >= 50)
 {
  echo "<br>";
  echo "<br>".$name;
 }
}
?>