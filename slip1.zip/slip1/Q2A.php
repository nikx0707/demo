<?php
class MyCalculator
{
private $fval, $sval;
public function __construct( $fval, $sval )
{
$this->fval = $fval;
$this->sval = $sval;
}
public function add()
{
return $this->fval + $this->sval;
}
public function subtract()
{
return $this->fval - $this->sval;
}
public function multiply()
{
return $this->fval * $this->sval;
}
public function divide()
{
return $this->fval / $this->sval;
}
}
$mycalc = new MyCalculator(18, 3);
echo "Divide:-",$mycalc-> divide()."\n <br>";
?>
