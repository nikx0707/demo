<?php

$xml = simplexml_load_file("demo.xml");

$xmlstring = $xml->asXML();

echo $xmlstring;
?>