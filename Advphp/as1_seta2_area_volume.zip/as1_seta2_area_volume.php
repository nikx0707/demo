<?php

$r=$_GET['r'];
$h=$_GET['h'];

define ( 'PI','3.14');

interface Cal
{
    function area($r,$h);
    function volume($r,$h);
}
   
class Cylinder implements Cal
    {
       function area($r,$h)
       {
           $area = 2 * PI *$r * ($r * $h);
           echo "<h3> The Area of Circle is :  $area </h3>";
       } 
       function volume($r,$h)
       {
           $volume = PI * $r * $r * $h;
           echo "<h3> The Volume of Circle is : $volume </h3>"; 
       }
    
    }
    $c =new Cylinder();
    $c-> area($r,$h);
    $c-> volume($r,$h);
    
?>