<html>
<title>multi value parameter</title>
<body>

<form method=get action="">

Enter Your Name :<input type=text name=t1 value="<?php if(isset($_GET['t1'])) echo $_GET['t1'];?>"><br>
Select Your Cities :

<select name=cities >
<option value=Pune>Pune</option>
<option value=Mumbai>Mumbai</option>
<option value=Raigad>Raigad</option>
<option value=Beed>Beed</option>
<option value=Sambhajinagar>Sambhajinagar</option>

</select>
<br>

<input type=submit value=Submit..!><br>

    </form>
  </body>
</html>

<?php

	$city=$_GET['cities'];
	$name=$_GET['t1'];

	if(isset($city,$name))
	{
	 if($city==""||$name=="")
	  {
		echo "you Selected Nothing ";
	  }
	else
	  {
		echo "Your Name :$name<br>";
		echo "and You want to visit $city ";
	  }
	}
?>