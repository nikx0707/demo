<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sticky Forms ....!!!</title>
</head>
<body>
    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" >
    <b>Your First Name : </b>
    <input type="text" name="fname" value="<?php if(isset($_POST['fname'])) echo $_POSt['fname']; ?>" >
    <b>Your Last Name : </b>
    <input type="text" name="lname" value="<?php if(isset($_POST['lname'])) echo $_POSt['lname'];?>" >
    <b>Your Class : </b>
    <input type="text" name="cname" value="<?php if(isset($_POST['cname'])) echo $_POSt['cname']; ?>" >

    <p><input type="submit" name="submit" value="Submit.!"></p>
</form>

<?php
echo "Your Name is = ".$_POST['fname']."<br>";
echo "Your Last Name is = ".$_POST['lname']."<br>";
echo "Your Name is = ".$_POST['cname']."<br>";
?>
</body>
</html>