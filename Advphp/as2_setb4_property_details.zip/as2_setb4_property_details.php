<html>
<title>multi value parameter</title>
<body>

<form method=get action="">

Enter Client Name :<input type=text name=t1 value="<?php if(isset($_GET['t1'])) echo $_GET['t1'];?>"><br>
Select Your Property Type :

<select name=cities >
<option value=Flat>Flat</option>
<option value=Bunglow>Bunglow</option>
<option value=Plot>Plot</option>
</select>
<br>

<input type=submit value=Submit..!><br>

    </form>
  </body>
</html>

<?php

	$city=$_GET['cities'];
	$name=$_GET['t1'];

	if(isset($city,$name))
	{
	 if($city==""||$name=="")
	  {
		echo "you Selected Nothing ";
	  }
	else
	  {
		echo "Your Name : $name<br>";
		echo "and Your Property Type is : $city ";
	  }
	}
?>