<?php

interface myInterface
{
    public function getName();
    public function getAge();
}

class myClass implements myInterface
{
    public function getName()
    {
        echo " My Name is Nikhil"."<br>";
    }
    public function getAge()
    {
        echo " My Age is 20";
    }
}

$obj = new myClass;
$obj->getname();
$obj->getAge();

?>