<html>
  <head>
    <body>
        <?php

$xml=simplexml_load_file("Q2B.xml") or die("cannot connnect");
?>

<center></b>Cricket details</b></center>
<table border="1">
    <th>Team</th>
    <th>player</th>
    <th>runs</th>
    <th>wickets</th>

    <?php
    foreach($xml->Team as $a)
{
    echo"<tr><td>".$a['country']."</td>";
    echo"<td>".$a->player."</td>";
    echo"<td>".$a->runs."</td>";
    echo"<td>".$a->wickets."</td>";
}
?>

</table>
</body>
</html>
    