#include<iostream>
using namespace std;

class integer
{
    public:
     int x,y;
     void getData();
     void display();
     void swap(int &, int &);
};

void integer::getData()
{
    cout<<" Enter the Value of X and Y : ";
    cin>>x>>y;
}

void integer::display()
{
    cout<<"x = "<<x<<endl;
    cout<<"y = "<<y;
}

void integer::swap(int &p, int &q)
{
    int temp;
    temp=p;
    p=q;
    q=temp;  

    cout<<endl<<"After Swap : "<<endl;
    cout<<"x= "<<x<<endl;
    cout<<"y= "<<y;

}

int main()
{   
    integer i;
    int x,y;
    i.getData();
    i.display();
    i.swap(x,y);

    return 0;
}
