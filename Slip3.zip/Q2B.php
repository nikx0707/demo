<?php
 $show=simplexml_load_file("Q2B.xml") or die("cannot load");
 $xmlstring=$show->asXML();
 echo $xmlstring;

?>