#include<iostream>
#include<fstream>
using namespace std;

int main()
{
 ofstream out;
 int a[10]={1,2,3,4,555,666,77,88,9};
 int b[10];

 out.open("input.txt");
 out.write((char*) &a, sizeof (a));
 out.close();

ifstream in;
ofstream fp1,fp2;
in.open("input.txt");
in.read((char*) &b, sizeof(b));
fp1.open("even.txt");
fp2.open("odd.txt");

for(int i=0; i<10; i++)
{
    if(b[i]%2==0)
    fp1<<b[i]<<"";

    else
    fp2<<b[i]<<"";
}

in.close();
fp1.close();
fp2.close();

ifstream fp;
char ch;
fp.open("even.txt");
cout<<"The Even File contents are: ";
while(fp)
{
    fp.get(ch);
    cout<<ch;
}
fp.close();

fp.open("odd.txt");
cout<<endl<<"The Odd File contents are :";
while (fp)
{
    fp.get(ch);
    cout<<ch;
}
fp.close();

return 0;

}