<?php

$dom = new DomDocument();
$dom -> load("Q2B.xml");
print $dom -> saveXML()."<br>";
print $dom -> save("newfile.doc");

?>