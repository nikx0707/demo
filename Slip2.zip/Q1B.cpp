#include <iostream>
#include <fstream>
using namespace std;

class Movie
{
public:
    int year;
    char mname[20];
    char dname[15];
    int budget;

public:
    void accept()
    {
        cout << "Enter the movie name:-";
        cin >> mname;
        cout << "Enter the Release year:";
        cin >> year;
        cout << "Enter the Director Name:-";
        cin >> dname;
        cout << "Enter the Budget-";
        cin >> budget;
    }

    void display()
    {
        cout <<endl<< "The movie name = " << mname;
        cout <<endl<< "The Release year = " << year;
        cout <<endl<< "The Director_Name = " << dname;
        cout <<endl<< "The Budget = " << budget;
    }
};

int main()
{
    Movie m[5];
    int n, i;

    fstream file;
    file.open("Movie.bet", ios::in | ios::out);

    cout << endl<<"Enter the Number of records you want to enter : ";
    cin >> n;

    for (i = 0; i < n; i++)
    {
        m[i].accept();
        file.write((char *)&m[i], sizeof(m[i]));
    }
    cout << "\nDetails of Movie from the file :- ";

    for (i = 0; i < n; i++)
    {
        file.read((char *)&m[i], sizeof(m[i]));
        m[i].display();
    }

    file.close();
    return 0;
}
