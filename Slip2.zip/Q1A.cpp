#include<iostream>
using namespace std;

float vol(int radius ,int height)
{
    return( 3.14 * radius * radius * height);
}

float vol(float radius)
{
    return((4 * 3.14 * radius * radius * radius )/3);
}

float vol(float radius, int height)
{
    return(3.14 * radius * radius *( height / 3));
}

int main()
{
    int radius, height, radius2, height2;
    float radius1;

    cout<<"Enter the radius & height of the cylinder : ";
    cin>>radius>>height;

    cout<<"Enter the radius of the sphere : ";
    cin>>radius1;

    cout<<"Enter the radius & height of cone : ";
    cin>>radius2>>height2;

    cout<<"Volume of the Cylinder : "<<vol(radius,height)<<endl;
    cout<<"Volume of the Sphere : "<<vol(radius1)<<endl;
    cout<<"Volume of the cone : "<<vol(radius2,height2)<<endl;

    return 0;
}