<?php

class myClass
{
    public $a;
    public $b=1;
    public $c='Nikhil';

    function myClass()
    {
        //function
    }

    function myfunc1()
    {
        //function defination
    }

    function myfunc2()
    {
        //function defination
    }
}

$class=get_declared_classes();
foreach($class as $cname)
{
    echo "$cname<br>";
}

echo "<br> Class Methhods are : <br>";
$m=get_class_methods('myClass');
foreach($m as $mname)
{
    echo "$mname<br>";
}

$cp=get_class_vars('myClass');
echo"Class variable are : <br>";
foreach($cp as $cpname => $v)
{
    echo " $cpname : $v <br>";
}

?>